package com.backend.a3BE;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A3BeApplication {

	public static void main(String[] args) {
		SpringApplication.run(A3BeApplication.class, args);
	}

}
