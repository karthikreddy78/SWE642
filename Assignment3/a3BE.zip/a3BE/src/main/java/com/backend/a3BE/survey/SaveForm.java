/**
 * 
 */
package com.backend.a3BE.survey;

/**
 * 
 */
public class SaveForm {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
