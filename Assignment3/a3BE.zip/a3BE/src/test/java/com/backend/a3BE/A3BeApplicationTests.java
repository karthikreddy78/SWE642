package com.backend.a3BE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A3BeApplicationTests {

	@Test
	void contextLoads() {
	}

}
